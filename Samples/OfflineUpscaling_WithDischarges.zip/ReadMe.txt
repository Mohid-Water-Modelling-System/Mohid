To make an upscaling simulation, you will need to first make a ONEWay simulation (implementation files are in the corresponding folder in "data")

After this simulation, the CD results must be copied to the boundary conditions of the PD. Then a new simulation must be run for the same period,
but now with the implemenentation for Upscaling (files are under the folder "data")